import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { AuthenticationStatus } from '../models/AuthenticationStatus.model';
import { Patient } from '../models/patient';

@Injectable({
  providedIn: 'root'
})
export class PatientloginService {

  constructor(private httpClient: HttpClient) {}



  authenticated(patient:Patient){
    return this.httpClient.post<AuthenticationStatus>(
        'http://localhost:8081/api/v1/patientlogin',patient
    );

    }
}