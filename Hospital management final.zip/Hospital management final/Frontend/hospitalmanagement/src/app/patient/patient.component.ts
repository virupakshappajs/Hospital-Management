import { Component, OnInit } from '@angular/core';
//import { FormsModule} from '@angular/forms';
import { NgForm } from '@angular/forms';
import { ActivatedRoute,Router } from '@angular/router';
import { AuthenticationStatus } from '../models/AuthenticationStatus.model';
import { Patient } from '../models/patient';
import { PatientloginService } from '../services/patientlogin.service';

@Component({
  selector: 'app-patient',
  templateUrl: './patient.component.html',
  styleUrls: ['./patient.component.css']
})
export class PatientComponent implements OnInit {
  authStatus: AuthenticationStatus | undefined;
  constructor(
    private patientloginService: PatientloginService,
    private router: Router,
    private route: ActivatedRoute
  ) { }


  ngOnInit(): void { }
  patientlogin:Patient=new Patient()
  
  // onSubmit(form: NgForm) {
     
  //     this.patientlogin={
  //       p_id:0,   
  //       p_name:'',
  //       p_contact_no:0,
  //       p_gender:'',
  //       username:form.value.username,
  //       password:form.value.password,
  //     }
  //   console.log(form.value.username, form.value.password);

  //   this.patientloginService
  //   .authenticated(this.patientlogin)
  //   .subscribe((res) => {
  //     this.authStatus = res;
  //     if (this.authStatus.authenticated) {
  //       alert("Successfully logged in!")
  //       this.router.navigate(['/patienthomepage'], {relativeTo: this.route});
  //     }
  //     else {
  //       alert("Invalid Credentials!")
  //       this.router.navigate(['/patient'], { relativeTo: this.route});
  //       form.reset();
  //     }
  //   });
  // isAdmin:boolean = false;
  // isUser:boolean = false;
  // constructor(
  //   private router:Router,
  //   private route:ActivatedRoute
  // ) { }

  // ngOnInit(): void {}
  // onSubmit(form: NgForm) {
  //   let userName = form.value.userName;
  //   let password = form.value.password;

  //     if(this.isUser)
  //     {
  //       this.router.navigate(['/patient'], { relativeTo: this.route });
  //     } 
  //     else
  //     {
        
  //         if(this.isAdmin){
  //         this.router.navigate(['/admin/medicines'], { relativeTo: this.route });
  //       }
  //     if(!this.isAdmin && !this.isUser){
  //      alert("username and password do not match or username doesnot exists please redirect to signup page and register")
  //      form.reset();   
  //      }
  //       };
       

  //  goTosignup (action : String) {
    // this.router.navigate(['/patient'], { relativeTo: this.route }); }

  
    onSubmit(name:string,pass:string ) {
     
      this.patientlogin={
        p_id:0,   
        p_name:'',
        p_contact_no:0,
        p_gender:'',
        username:name,
        password:pass,
      }
// console.log(fo    rm.value.username, form.value.password);
// console.log(form.value.username, form.value.password);
//     sessionStorage.setItem("username",form.value.username);
//     sessionStorage.setItem("password",form.value.password);
    console.log(name, pass);
    this.patientloginService
    .authenticated(this.patientlogin)
    .subscribe((res) => {
      this.authStatus = res;
      if (this.authStatus.authenticated) {
        alert("Successfully logged in!")
        this.router.navigate(['/patienthomepage'], {relativeTo: this.route});
      }
      else {
        alert("Invalid Credentials!")
        this.router.navigate(['/patient'], { relativeTo: this.route});
        // form.reset();
      }
    });

  }
};