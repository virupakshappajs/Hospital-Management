import { Patientslist } from './patientslist';

describe('Patientslist', () => {
  it('should create an instance', () => {
    expect(new Patientslist()).toBeTruthy();
  });
});
