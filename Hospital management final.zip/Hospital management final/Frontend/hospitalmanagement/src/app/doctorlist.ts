export class Doctorlist {
    d_id!:number;
    d_name! : string;
    gender!:  string;
    username!:string;
    password!:string;
    contact_no!:string;
    address!:string;
    specialization!: string;
    experiance!: string;
    salary!: string;
    accept!: string

}
