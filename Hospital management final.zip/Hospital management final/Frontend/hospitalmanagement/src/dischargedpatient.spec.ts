import { Dischargedpatient } from './app/models/dischargedpatient';

describe('Dischargedpatient', () => {
  it('should create an instance', () => {
    expect(new Dischargedpatient()).toBeTruthy();
  });
});
